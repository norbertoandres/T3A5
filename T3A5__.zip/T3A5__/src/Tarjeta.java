public class Tarjeta {
    int numero;
    int nip;
    
    public Tarjeta() {
    }
    public Tarjeta(int numero, int nip) {
        this.numero = 123456789;
        this.nip = 1234;
        
    }
    
    public int getNumero() {
        return numero;
    }
    
    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    public int getNip() {
        return nip;
    }
    
    
}

