package t3a5__2;

import java.util.Scanner;

public class T3A5__2 {

    public static void main(String[] args) {
        menu();

    }

    public static void menu() {

        Scanner scanner = new Scanner(System.in);
        Cuenta cuenta = new Cuenta();
        Scanner sacnner = new Scanner(System.in);

        System.out.println("BIENVENIDO AL BANCO X"
                + "1. Consultar saldo\n"
                + "2. Consultar estado de cuenta\n"
                + "3. Retirar efectivo\n"
                + "4. Otras opciones\n"
                + "5. Salir"
                + "\n\nElija una operacion");

        int operacion = scanner.nextInt();

        switch (operacion) {
            case 1:
                cuenta.seguros();
                break;
            case 2:
                cuenta.estadoDeCuenta();
                break;
            case 3:
                cuenta.retirarEfectivo();
                break;
            case 4:
                System.out.println("1; Seguros\n"
                        + "2 Creditos\n\n"
                        + "Elija uno:");
                int opcion = scanner.nextInt();
                switch (opcion) {
                    case 1:
                        cuenta.seguros();
                        break;

                    case 2:
                        cuenta.creditos();
                        break;

                    default:
                        System.err.println("Elija una opcion calida");
                        break;

                }
        
        }
    }

}
