package t3a5__;

import java.util.Scanner;

public class T3A5__ {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Menu de la aplicacion"
                + "\n\n1. Consultar saldo"
                + "\n2. Consultar estado de cuenta"
                + "\n3. Retirar efectivo"
                + "\n4. consultarSeguros"
                + "\n.5 consultarCreditos"
                + "\n.6 Salir"
                + "\n\n.  Elija una opcion del menu");

        int opcion = scanner.nextInt();
        // Estructura para organizar opciones
        switch (opcion) {
            case 1:
                consultarSaldo();
                break;
            case 2:
                consultarCuenta();
                break;

            case 3:
                retirarEfectivo();
                break;

            case 4:
                consultarSeguros();
                break;

            case 5:
                consultarCreditos();
                break;

            case 6:
                Salir();
                break;

            default:
                System.out.println("Elija una opcion valida");
                break;

        }

        System.out.println();

    }

    public static void consultarSaldo() {
        System.out.println("Su saldo es de 1000");
    }

    public static void consultarCuenta() {
        System.out.println("Su cuenta esta a salvo");
    }

    public static void retirarEfectivo() {
        System.out.println("Cuanto desea retirar.");
    }

    public static void consultarSeguros() {
        System.out.println("Usted cuenta con un seguro.");
    }

    public static void consultarCreditos() {
        System.out.println("Usted tien un credito de nomina");

    }
    
    public static void Salir() {
        System.out.println("Gracias por usar el sofware :D");
    }
}



    

    




